﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestNum2_Rik
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int score1 = 8;
            int score2 = 6;
            int score3 = 9;
            int score4 = 4;
            int scorMax = 10;


            int averangeValue = (8 + 6 + 9 + 4) / 4;
            Console.WriteLine("The value number is " + averangeValue);
            //Console.WriteLine(averangeValue / scorMax);




        }
    }
}
