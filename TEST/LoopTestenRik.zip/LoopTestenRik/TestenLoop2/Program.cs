﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestenLoop2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("voer een zin in: ");
            string zin = Console.ReadLine().ToLower();

            foreach (char i in zin)
            {
                if
            }
        }
    }
}
