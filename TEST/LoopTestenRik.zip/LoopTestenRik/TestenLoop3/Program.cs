﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestenLoop3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a few sentences that u want: ");
            string sentences = Console.ReadLine();

            int numberSentences = 0;
            bool lettersOrNumbers = false;

            foreach (char z in sentences)
            {
                if (char.IsLetterOrDigit(z))
                {
                    lettersOrNumbers = true;
                }
                else
                {
                    if (lettersOrNumbers)
                    {
                        numberSentences++;
                        lettersOrNumbers = false;
                    }
                }
            }
            if (lettersOrNumbers)
            {
                numberSentences++;
            }
            Console.WriteLine("The numbers of in sentence is: " + numberSentences);
            Console.ReadLine();
        }
    }
}
